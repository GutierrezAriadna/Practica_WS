/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviciosWeb;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Saul
 */
@WebService(serviceName = "calc")
public class calc {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    
    @WebMethod(operationName="resultado")
    public String resultado(@WebParam(name="primerNum")String primerNum,
                            @WebParam(name="segundoNum")String segundoNum,
                            @WebParam(name="operacion")String operacion)
    {
        String resultadoOperacion="";
        double primerN=Double.parseDouble(primerNum);
        double segundoN=Double.parseDouble(segundoNum);
        switch(operacion)
        {
            case "1":
                resultadoOperacion=""+(primerN+segundoN);
                break;
            case "2":
                resultadoOperacion=""+(primerN-segundoN);
                break;
            case "3":
                resultadoOperacion=""+(primerN/segundoN);
                break;
            case "4":
                resultadoOperacion=""+(primerN*segundoN);
                break;
        }
        return resultadoOperacion;
    }
}
