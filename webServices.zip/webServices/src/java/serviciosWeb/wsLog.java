/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviciosWeb;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Saul
 */
@WebService(serviceName = "wsLog")
public class wsLog {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    
    @WebMethod(operationName="entrar")
    public String entrar(@WebParam(name="usr")String usr,@WebParam(name="pass")String pass)
    {
        String access="";
        if(usr.isEmpty() || pass.isEmpty()){
            access="Datos vacíos";
        }else if(usr.equalsIgnoreCase("Ari"))
            if(pass.equalsIgnoreCase("Ari"))
                access="Acceso permitido";
            else
                access="Contraseña incorrecta";
        else
            access="Nombre de usuario incorrecto";
        
        return access;
    }
}
