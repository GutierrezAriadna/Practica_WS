/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviciosWeb;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author Saul
 */
@Path("div")
public class DivResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of DivResource
     */
    public DivResource() {
    }

    /**
     * Retrieves representation of an instance of serviciosWeb.DivResource
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getXml() {
        //TODO return proper representation object
       return "Servicio en línea";
    }

    @GET
    @Path("/convertir/moneda={moneda}&pesos={pesos}")
    @Produces(MediaType.TEXT_PLAIN)
    public String convertir(@PathParam("moneda")String moneda,@PathParam("pesos")String pesos){
        String conversion="";
        switch(moneda)
        {
            case "1":
                conversion=""+(Double.parseDouble(pesos)/17);
                break;
            case "2":
                conversion=""+(Double.parseDouble(pesos)/20);
                break;
            case "3":
                conversion=""+(Double.parseDouble(pesos)/25);
                break;
            case "4":
                conversion=""+(Double.parseDouble(pesos)/.17);
                break;
            case "5":
                conversion=""+(Double.parseDouble(pesos)/13);
                break;
        }
        return conversion;
    }
    /**
     * PUT method for updating or creating an instance of DivResource
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
}
